Django 1.10.4
Python 3.5.2

su login: django
password: geekbrains

users list and delete user: /admin/ 
